# fhi 2019.02.21

Cleaning up for CRAN submission

# fhi 2018.10.12

## Migration

Migrating from [raubreywhite/fhi](https://www.github.com/raubreywhite/fhi/) to [folkehelseinstituttet/fhi](https://www.github.com/folkehelseinstituttet/fhi/)
