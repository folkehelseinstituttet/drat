## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
# start off with base map
pd <- fhidata::norway_map_counties_b2020

# create some fictional data
data <- unique(pd[,c("location_code")])
suppressWarnings(data[,category:=rep(c("High","Medium","Low"),each=5)[1:.N]])
data[,category_with_missing:=category]
data[1,category_with_missing:="Missing"]
data[,category:=factor(category,levels=c("High","Medium","Low"))]
data[,category_with_missing:=factor(category_with_missing,levels=c("High","Medium","Low","Missing"))]
data[location_code == "county54", category:='Low']
data[location_code == "county54", category_with_missing:='Low']

# merge the data into the map
pd[data,on="location_code",category:=category]
pd[data,on="location_code",category_with_missing:=category_with_missing]

## ----fig.height=7, fig.width=7------------------------------------------------
library(ggplot2)
library(fhiplot)

q <- ggplot()
q <- q + geom_polygon(data = pd, aes( x = long, y = lat, group = group, fill=category), color="black")
q <- q + theme_void()
q <- q + coord_quickmap()
q <- q + fhiplot::scale_fill_fhi("Category",palette = "map_seq_complete", direction = 1, drop=F)
q <- q + labs(title = "Palette = map_seq_complete")
q

## ----fig.height=7, fig.width=7------------------------------------------------
library(ggplot2)
library(fhiplot)

q <- ggplot()
q <- q + geom_polygon(data = pd, aes( x = long, y = lat, group = group, fill=category), color="black")
q <- q + theme_void()
q <- q + coord_quickmap()
q <- q + fhiplot::scale_fill_fhi("Category",palette = "map_seq_x2_complete", direction = 1, drop=F)
q <- q + labs(title = "Palette = map_seq_x2_complete")
q

## ----fig.height=7, fig.width=7------------------------------------------------
library(ggplot2)
library(fhiplot)

q <- ggplot()
q <- q + geom_polygon(data = pd, aes( x = long, y = lat, group = group, fill=category_with_missing), color="black", size=0.2)
q <- q + theme_void()
q <- q + coord_quickmap()
q <- q + fhiplot::scale_fill_fhi("Category",palette = "map_seq_missing", direction = 1, drop=F)
q <- q + labs(title = "Palette = map_seq_missing")
q

## ----fig.height=7, fig.width=7------------------------------------------------
library(ggplot2)
library(fhiplot)

q <- ggplot()
q <- q + geom_polygon(data = pd, aes( x = long, y = lat, group = group, fill=category_with_missing), color="black", size=0.2)
q <- q + theme_void()
q <- q + coord_quickmap()
q <- q + fhiplot::scale_fill_fhi("Category",palette = "map_seq_missing_x2", direction = 1, drop=F)
q <- q + labs(title = "Palette = map_seq_missing_x2")
q

## ----fig.height=7, fig.width=7------------------------------------------------
library(ggplot2)
library(fhiplot)

q <- ggplot()
q <- q + geom_polygon(data = pd, aes( x = long, y = lat, group = group, fill=category_with_missing), color="black", size=0.2)
q <- q + theme_void()
q <- q + coord_quickmap()
q <- q + fhiplot::scale_fill_fhi("Category",palette = "map_seq_x2_missing", direction = 1, drop=F)
q <- q + labs(title = "Palette = map_seq_x2_missing")
q

## ----fig.height=7, fig.width=7------------------------------------------------
library(ggplot2)
library(fhiplot)

q <- ggplot()
q <- q + geom_polygon(data = pd, aes( x = long, y = lat, group = group, fill=category_with_missing), color="black", size=0.2)
q <- q + theme_void()
q <- q + coord_quickmap()
q <- q + fhiplot::scale_fill_fhi("Category",palette = "map_seq_x2_missing_x2", direction = 1, drop=F)
q <- q + labs(title = "Palette = map_seq_x2_missing_x2")
q

