library(testthat)
library(sykdomspulspdf)

test_check("sykdomspulspdf")
