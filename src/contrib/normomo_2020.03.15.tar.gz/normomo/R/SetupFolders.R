#' SetupFolders
#' @param folder_results a
#' @param dateDataMinusOneWeek a
#' @importFrom RAWmisc YearWeek
#' @import data.table
#' @export SetupFolders
SetupFolders <- function(
                         folder_results = fd::path("results"),
                         dateDataMinusOneWeek) {
  unlink(file.path(folder_results, RAWmisc::YearWeek(dateDataMinusOneWeek)), recursive = TRUE, force = TRUE)

  dir.create(file.path(folder_results, RAWmisc::YearWeek(dateDataMinusOneWeek)))

  dir.create(file.path(
    folder_results,
    RAWmisc::YearWeek(dateDataMinusOneWeek),
    "MOMO"
  ))
}
