.onLoad <- function(libname, pkgname) {
  if (!fd::config$is_initialized) {
    fd::initialize(
      package = "normomo",
      load_package = FALSE
    )
  }
}
