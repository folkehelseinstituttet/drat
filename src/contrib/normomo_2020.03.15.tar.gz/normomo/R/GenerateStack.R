#' GenerateStack
#' @param folder_clean a
#' @param folder_results a
#' @param f a
#' @param dateDataMinusOneWeek a
#' @param dateData a
#' @import data.table
#' @export GenerateStack
GenerateStack <- function(
                          folder_clean = fd::path("data_clean"),
                          folder_results = fd::path("results"),
                          f,
                          dateDataMinusOneWeek,
                          dateData) {
  stack <- data.table(location_code = c("norway", unique(fd::norway_locations()$county_code)))

  stack[, data_clean_name := fs::path(folder_clean, glue::glue("{location_code}.RDS", location_code = location_code))]

  stack[, plotGraphs := FALSE]
  stack[1, plotGraphs := TRUE]

  stack[, MOMOFolderInput := folder_clean]

  stack[, MOMOFolderResults := file.path(
    folder_results,
    fhi::isoyearweek(dateDataMinusOneWeek),
    "MOMO"
  )]

  stack[, MOMOFolderResultsData := file.path(
    folder_results,
    fhi::isoyearweek(dateDataMinusOneWeek),
    "data",
    paste0(location_code, ".RDS")
  )]

  stack[, MOMOFolderResultsGraphsStatus := file.path(
    folder_results,
    fhi::isoyearweek(dateDataMinusOneWeek),
    "graphs_status"
  )]

  stack[, MOMOFolderResultsGraphsStatistics := file.path(
    folder_results,
    fhi::isoyearweek(dateDataMinusOneWeek),
    "graphs_statistics"
  )]

  stack$MOMOYsum <- fhi::isoyear_n(dateDataMinusOneWeek)
  stack$dateDataMinusOneWeek <- dateDataMinusOneWeek
  stack$dateData <- dateData
  # stack$dateData[[1]] <- c(dateData-seq(4*52*7,0,by=-7))
  # stack$dateData[[1]] <- c(dateData-seq(4*52*7,0,by=-7))
  # for(i in 1:nrow(stack)) stack$dateData[[i]] <- dateData

  tmp <- list(
    list(
      "0to4" = "age >= 0 & age <=4",
      "5to14" = "age >= 5 & age <=14",
      "15to64" = "age >= 15 & age <=64",
      "65P" = "age >= 65 | is.na(age)",
      "Total" = "age >= 0 | is.na(age)"
    )
  )
  for (i in unique(fd::norway_locations()$county_code)) {
    tmp[[i]] <- list(
      "Total" = "age >= 0 | is.na(age)"
    )
  }
  stack$MOMOgroups <- tmp

  tmp <- list(
    c(
      "0to4" = "LINE",
      "5to14" = "LINE",
      "15to64" = "LINE_SIN",
      "65P" = "LINE_SIN",
      "Total" = "LINE_SIN"
    )
  )
  for (i in unique(fd::norway_locations()$county_code)) {
    tmp[[i]] <- c(
      "Total" = "LINE_SIN"
    )
  }
  stack$MOMOmodels <- tmp

  years_to_run <- 2014:fhi::isoyear_n(stack$dateData[1]) - 1
  res <- vector("list", length = length(years_to_run))
  for (i in 1:length(res)) {
    df1 <- copy(stack)
    df1$dateData <- as.Date(glue::glue("{years_to_run[i]}-02-01"))
    df1$plotGraphs <- FALSE
    res[[i]] <- df1
  }
  res <- rbindlist(res)
  res[, MOMOFolderResults := tempdir()]

  return(list(
    plan_operational = stack,
    plan_historic = res
  ))
}
