# fhiplot 2019.5.8

- fixed format_nor, huxtable, palette order
- included format_date_nor, theme_fhi_lines_horizontal

# fhiplot 2019.3.28

2 new palettes:

- posneg
- warning

2 new functions:

- format_nor_perc_0
- format_nor_perc_1

# fhiplot 2019.3.18

Allow more than 9 colors in a palette

# fhiplot 2019.1.29

Included "sig" (significant digits) to format_nor

# fhiplot 2019.1.27

Upgraded to latest version of FHI style guide: https://xd.adobe.com/spec/df67b92d-361b-4c1c-6757-7a0379498356-a956/
