#' A test function
#' @param data Data
#' @param argset argset
#' @export
fn_test <- function(data, argset) {
  return(1)
}
