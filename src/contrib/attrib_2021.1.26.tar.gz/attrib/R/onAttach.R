.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: attrib")
  packageStartupMessage("Version: 2021.01.26 at 04:56")
}
