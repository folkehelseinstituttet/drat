.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhiplot")
  packageStartupMessage("Version 2020.11.25 at 09:42")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}
