.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhiplot")
  packageStartupMessage("Version 2021.01.22 at 11:12")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}
