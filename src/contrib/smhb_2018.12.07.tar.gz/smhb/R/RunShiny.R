RunShiny <- function() {
  options(shiny.port = 4989)
  options(shiny.host = "0.0.0.0")
  shiny::runApp(file <- system.file("shiny", "smhb", package = "smhb"))
}
