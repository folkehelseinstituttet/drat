.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: smhb")
  packageStartupMessage("Version 2018.12.07 at 14:32")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}
