library(testthat)
library(smhb)

test_check("smhb")
