library(stringr)
context("String length")

test_that("str_length is number of characters", {
  testthat::expect_equal(1, 1)
})
