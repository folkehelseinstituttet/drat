#' An easy way to print github code
#' @param url URL from github
#' @examples
#' x <- as_github_code("https://raw.githubusercontent.com/folkehelseinstituttet/scskeleton/main/R/00_env_and_namespace.r")
#' x <- as_github_code("https://github.com/folkehelseinstituttet/scskeleton/blob/main/R/00_env_and_namespace.r")
#' print(x, lines = 3:5)
#' @export
as_github_code <- function(url){
  if(stringr::str_detect(url, "^https://github.com/") | stringr::str_detect(url, "^https://www.github.com/")){
    url <- stringr::str_replace(url, "^https://www.github.com/", "https://raw.githubusercontent.com/")
    url <- stringr::str_replace(url, "^https://github.com/", "https://raw.githubusercontent.com/")
    url <- stringr::str_replace(url, "/blob/", "/")
  }
  x <- readLines(url)
  attr(x, "class") <- c("github_code", class(x))
  x
}

print.github_code <- function(x, ...){
  dots <- list(...)
  if("lines" %in% names(dots)){
    lines <- dots[["lines"]]
  } else {
    lines <- seq_len(length(x))
  }
  max_lines <- max(lines)
  max_width <- log(max_lines, base = 10) |>
    floor() + 1
  for(i in lines){
    cat(formatC(i, width = max_width), " | ", x[i], "\n", sep = "")
  }
}
