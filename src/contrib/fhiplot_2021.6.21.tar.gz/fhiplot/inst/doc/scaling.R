## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
library(ggplot2)
library(fhiplot)
library(magrittr)

## -----------------------------------------------------------------------------
yrwk_19_20 <- fhidata::world_dates_isoyearweek[year %in% c(2019, 2020),
                                               .(year, yrwk)]

simulate_case <- function(yrwk_df, lambda_expected, lambda_observed, location_code){
  nweeks <- nrow(yrwk_df)
  n_observed <- rpois(nweeks, lambda_observed)
  n_expected <- rpois(nweeks, lambda_expected)

  df <- data.frame(deaths_n_observed = n_observed,
                   deaths_n_expected = n_expected,
                   location_code = location_code)
  df <- cbind(yrwk_df, df)
  return(df)
}


set.seed(1)
df_loc1 <- simulate_case(yrwk_df = yrwk_19_20,
                         lambda_expected = 1000,
                         lambda_observed = 500,
                         location_code = "county_A")
df_loc2 <- simulate_case(yrwk_df = yrwk_19_20,
                         lambda_expected = 1000,
                         lambda_observed = 2000,
                         location_code = "county_B")

dd <- rbind(df_loc1, df_loc2)
dd

## -----------------------------------------------------------------------------
# separate the yrwk string to produce week id

dd$week <- fhiplot::isoyearweek_to_week_n(dd$yrwk)
dd$year <- as.factor(dd$year)

# plot cases
q <- ggplot(dd, aes(x = week, y = deaths_n_observed, color = year))
q <- q + geom_line(lwd = 1.3)
q <- q + facet_wrap(~ location_code, nrow = 2, scale = 'free')
# use fhi themes
q <- q + fhiplot::theme_fhi_basic(10)
q <- q + fhiplot::scale_color_fhi("", palette = "primary", direction = -1)
q <- q + fhiplot::theme_fhi_lines_horizontal()
q <- q + guides(color = guide_legend(reverse = FALSE))
q <- q + labs(title = "Observed deaths (simulated data)", 
              x = "Week",
              y = "Number of death cases")
q

## -----------------------------------------------------------------------------
# compute excess and ratio by year
dd[, cum_excess := cumsum(deaths_n_observed - deaths_n_expected),
   by = list(location_code, year)]
dd[, cum_excess_ratio := cumsum(deaths_n_observed)/cumsum(deaths_n_expected),
   by = list(location_code, year)]
dd

## -----------------------------------------------------------------------------
max_val <- max(abs(dd$cum_excess_ratio))
q <- ggplot(dd, aes(x=week, y=cum_excess_ratio, color = year))
q <- q + geom_line(lwd = 1.3)
q <- q + geom_hline(yintercept = 1, lty = 2)
q <- q + facet_wrap(~ location_code, nrow = 1, scale = 'free')

q <- q + fhiplot::theme_fhi_basic(10)
q <- q + fhiplot::scale_color_fhi("", palette = "primary", direction = -1)
q <- q + guides(color = guide_legend(reverse = FALSE))
q <- q + scale_y_continuous(breaks = fhiplot::pretty_breaks(8),
                            labels = format_nor_num_2,
                            lim = c(0, max_val*1.2))
q <- q + labs(title = "Ratio of cumulative observed versus expected mortality (simulated data)", 
              x = "Week",
              y = "Ratio of cumulative mortality")
q

## -----------------------------------------------------------------------------
max_val <- max(abs(log2(dd$cum_excess_ratio)))
q <- ggplot(dd, aes(x=week, y=log2(cum_excess_ratio), color = year))
q <- q + geom_line(lwd = 1.3)
q <- q + geom_hline(yintercept = 0, lty = 2)
q <- q + facet_wrap(~ location_code, scale = 'free')

q <- q + fhiplot::theme_fhi_basic(10)
q <- q + fhiplot::scale_color_fhi("", palette = "primary", direction = -1)
q <- q + guides(color = guide_legend(reverse = FALSE))
q <- q + scale_y_continuous(breaks = fhiplot::pretty_breaks(9),
                            labels = format_nor_invlog2_2,
                            lim = c(-max_val, max_val))
q <- q + labs(title = "Ratio of cumulative observed versus expected mortality (simulated data)", 
              x = "Week",
              y = "Ratio of cumulative mortality")

q

