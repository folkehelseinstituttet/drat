library(testthat)
library(fhidata)

test_check("fhidata")
