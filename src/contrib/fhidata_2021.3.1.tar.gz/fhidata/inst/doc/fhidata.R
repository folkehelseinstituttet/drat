## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(fhidata)
library(data.table)

## -----------------------------------------------------------------------------
# All the available values of granularity_geo
unique(fhidata::norway_locations_names()$granularity_geo)

## -----------------------------------------------------------------------------
# All the available values location_code for granularity_geo=="county"
fhidata::norway_locations_names()[granularity_geo=="county"]$location_code

## -----------------------------------------------------------------------------
fhidata::set_config(border = 2020)

## -----------------------------------------------------------------------------
fhidata::norway_locations_redistricting()

## -----------------------------------------------------------------------------
fhidata::norway_locations_hierarchy(from = "wardoslo", to="municip")
fhidata::norway_locations_hierarchy(from = "municip", to="baregion")
fhidata::norway_locations_hierarchy(from = "county", to="faregion")

## -----------------------------------------------------------------------------
fhidata::norway_locations_names()[granularity_geo %in% c("county", "notmainlandcounty","missingcounty")]$location_code

## -----------------------------------------------------------------------------
fhidata::norway_locations_names()

## -----------------------------------------------------------------------------
fhidata::norway_population_by_age_cats(cats = list(c(1:10), c(11:20)))
fhidata::norway_population_by_age_cats(cats = list("one to ten" = c(1:10), "eleven to twenty" = c(11:20)))
fhidata::norway_population_by_age_cats(cats = list(c(1:10), c(11:20), "21+"=c(21:200)))

## -----------------------------------------------------------------------------
fhidata::norway_population_by_age_sex_cats(cats = list(c(1:10), c(11:20)))
fhidata::norway_population_by_age_sex_cats(cats = list("one to ten" = c(1:10), "eleven to twenty" = c(11:20)))
fhidata::norway_population_by_age_sex_cats(cats = list(c(1:10), c(11:20), "21+"=c(21:200)))

