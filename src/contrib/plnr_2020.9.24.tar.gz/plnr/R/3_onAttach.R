.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: plnr")
  packageStartupMessage("Version 2020.09.24 at 12:37")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}
