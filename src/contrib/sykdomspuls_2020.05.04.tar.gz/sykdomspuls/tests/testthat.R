library(testthat)
library(sykdomspuls)

test_check("sykdomspuls")
