.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhiplot")
  packageStartupMessage("Version 2020.11.23 at 12:21")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}
