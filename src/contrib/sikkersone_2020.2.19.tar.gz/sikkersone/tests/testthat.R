library(testthat)
library(sikkersone)

test_check("sikkersone")
