sykdomspuls_linelist <- function() {
  # Hente data fra grunndataene sykdomspulsen:

  # library(RODBC)
  db <- RODBC::odbcDriverConnect("driver={Sql Server};server=dm-prod;database=SykdomspulsenDvh; trusted_connection=true")


  # Henter ut alle data for Ask¯y og diagnose er D70 (Tarminfeksjon):
  res <- RODBC::sqlQuery(db, "select * from sluttbruker.V_Konsultasjon where KonsKommuneNr='1247'and Diagnose='D70'")
  # head(res)
  # dim(res)
  close(db)

  # write.table(res, "G:/Helseregistre/MSIS/Sykdomspulsen/Gry/Mage-tarm/MageTarm Ask¯y/Tarminfeksjon Ask¯y 20190613.txt", sep="\t")
}
