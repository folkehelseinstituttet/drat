.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: sikkersone")
  packageStartupMessage("Version: 2020.02.19 at 13:40")
}
