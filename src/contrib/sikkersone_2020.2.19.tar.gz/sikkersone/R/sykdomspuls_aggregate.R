sykdomspuls_aggregate_format_raw_data <- function(d, configs) {
  d[, influensa := 0]
  d[Diagnose %in% "R80", influensa := 1]

  d[, gastro := 0]
  d[Diagnose %in% c("D11", "D70", "D73"), gastro := 1]

  d[, respiratory := 0]
  d[Diagnose %in% c("R05", "R74", "R78", "R83"), respiratory := 1]

  d[, respiratoryexternal := 0]
  d[Diagnose %in% c("R05", "R74", "R78", "R83"), respiratoryexternal := 1]

  d[, respiratoryinternal := 0]
  d[Diagnose %in% c("R05", "R74", "R83"), respiratoryinternal := 1]

  d[, lungebetennelse := 0]
  d[Diagnose %in% "R81", lungebetennelse := 1]

  d[, bronkitt := 0]
  d[Diagnose %in% "R78", bronkitt := 1]

  d[, skabb := 0]
  d[Diagnose %in% "S72", skabb := 1]

  ####
  d[, emerg1 := 0]
  d[Diagnose %in% "R80", emerg1 := 1]

  d[, emerg2 := 0]
  d[Diagnose %in% "R80", emerg2 := 1]

  d[, emerg3 := 0]
  d[Diagnose %in% "R80", emerg3 := 1]

  d[, emerg4 := 0]
  d[Diagnose %in% "R80", emerg4 := 1]

  d[, emerg5 := 0]
  d[Diagnose %in% "R80", emerg5 := 1]


  d[, age := "Ukjent"]
  d[Alder == "0-4", age := "0-4"]
  d[Alder == "5-9", age := "5-14"]
  d[Alder == "10-14", age := "5-14"]
  d[Alder == "15-19", age := "15-19"]
  d[Alder == "20-29", age := "20-29"]
  d[Alder == "30-39", age := "30-64"]
  d[Alder == "40-49", age := "30-64"]
  d[Alder == "50-59", age := "30-64"]
  d[Alder == "60-64", age := "30-64"]
  d[Alder == "65-69", age := "65+"]
  d[Alder == "70-79", age := "65+"]
  d[Alder == "80+", age := "65+"]

  # Collapsing it down to 1 row per consultation
  d <- d[, .(
    influensa = sum(influensa),
    gastro = sum(gastro),
    respiratory = sum(respiratory),
    respiratoryexternal = sum(respiratoryexternal),
    respiratoryinternal = sum(respiratoryinternal),
    lungebetennelse = sum(lungebetennelse),
    bronkitt = sum(bronkitt),
    skabb = sum(skabb),
    emerg1 = sum(emerg1),
    emerg2 = sum(emerg2),
    emerg3 = sum(emerg3),
    emerg4 = sum(emerg4),
    emerg5 = sum(emerg5)
  ),
  by = .(
    KildeKonsultasjons_Id,
    KonsKommuneNr,
    age,
    KonsultasjonDato,
    Kontaktype,
    Praksis
  )
  ]

  # Collapsing it down to 1 row per kommune/age/day
  d <- d[, .(
    influensa = sum(influensa),
    gastro = sum(gastro),
    respiratory = sum(respiratory),
    respiratoryexternal = sum(respiratoryexternal),
    respiratoryinternal = sum(respiratoryinternal),
    lungebetennelse = sum(lungebetennelse),
    bronkitt = sum(bronkitt),
    skabb = sum(skabb),
    emerg1 = sum(emerg1),
    emerg2 = sum(emerg2),
    emerg3 = sum(emerg3),
    emerg4 = sum(emerg4),
    emerg5 = sum(emerg5),
    consult = .N
  ),
  by = .(
    KonsKommuneNr,
    age,
    KonsultasjonDato,
    Kontaktype,
    Praksis
  )
  ]

  d[, municip := paste0("municip", formatC(KonsKommuneNr, width = 4, flag = 0))]
  d[, KonsKommuneNr := NULL]
  setnames(d, "KonsultasjonDato", "date")

  return(d)
}

#' sykdomspuls_aggregate
#'
#' A function to extract aggregated sykdomspulsen data
#' @param date_from a
#' @param date_to a
#' @param folder a
#' @param ages a
#' @param ... a
#' @import data.table
#' @export
sykdomspuls_aggregate <- function(
                                  date_from = "2006-01-01",
                                  date_to = format(Sys.time(), "%Y-%m-%d"),
                                  folder = "G:/Helseregistre/MSIS/Sykdomspulsen/Gry/FormattingWithinSikkersone",
                                  ages = c(
                                    "0-4" = "0-4",
                                    "5-14" = "5-9",
                                    "5-14" = "10-14",
                                    "15-19" = "15-19",
                                    "20-29" = "20-29",
                                    "30-64" = "30-39",
                                    "30-64" = "40-49",
                                    "30-64" = "50-59",
                                    "30-64" = "60-64",
                                    "65-69" = "65+",
                                    "70-79" = "65+",
                                    "80+" = "65+"
                                  ),
                                  ...) {
  db <- RODBC::odbcDriverConnect("driver={Sql Server};server=dm-prod;database=SykdomspulsenDvh; trusted_connection=true")

  # calculate dates
  datesToExtract <- data.table(from = seq(as.Date(date_from), by = "month", length.out = 300), to = seq(as.Date(date_from), by = "month", length.out = 301)[-1] - 1)
  # Remove future dates
  datesToExtract <- datesToExtract[from <= date_to]

  # predefine storage of results
  pb <- utils::txtProgressBar(min = 1, max = nrow(datesToExtract), style = 3)
  for (i in 1:nrow(datesToExtract)) {
    command <- paste0(
      "select KildeKonsultasjons_Id,Diagnose,Alder,PasientKommuneNr,Kj\u00F8nn,KonsKommuneNr,KonsFylkeNr,KonsultasjonDato,Kontaktype,Praksis from sluttbruker.V_Konsultasjon where KonsultasjonDato >='",
      datesToExtract[i]$from,
      "' AND KonsultasjonDato <= '",
      datesToExtract[i]$to,
      "'"
    )
    d <- RODBC::sqlQuery(db, command)
    d <- data.table(d)
    d <- sykdomspuls_aggregate_format_raw_data(d)
    if (i == 1) {
      utils::write.table(d, paste0("partially_formatted_", format(Sys.time(), "%Y_%m_%d"), ".txt"), sep = "\t", row.names = FALSE, col.names = TRUE, append = FALSE)
    } else {
      utils::write.table(d, paste0("partially_formatted_", format(Sys.time(), "%Y_%m_%d"), ".txt"), sep = "\t", row.names = FALSE, col.names = FALSE, append = TRUE)
    }
    utils::setTxtProgressBar(pb, i)
  }
  close(pb)
}
