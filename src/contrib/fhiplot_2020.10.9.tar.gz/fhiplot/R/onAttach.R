.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhiplot")
  packageStartupMessage("Version 2020.10.09 at 05:55")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}
