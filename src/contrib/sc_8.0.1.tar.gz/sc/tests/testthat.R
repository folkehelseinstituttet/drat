library(testthat)
library(sc)

test_check("sc")
