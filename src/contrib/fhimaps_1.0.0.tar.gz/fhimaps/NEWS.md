# fhimaps 1.0.0

* Moving map files from fhidata to fhimaps
* Publishing to CRAN

