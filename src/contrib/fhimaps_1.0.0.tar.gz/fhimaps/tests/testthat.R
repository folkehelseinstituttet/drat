library(testthat)
library(fhimaps)

test_check("fhimaps")
