## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
library(fhiplot)

## -----------------------------------------------------------------------------
isoyear_c()
isoyear_n()
isoweek_c()
isoweek_n()

# provide a date
isoyear_c('2021-01-01')
isoyear_n('2021-01-01')
isoweek_c('2021-01-01')
isoweek_n('2021-01-01')

## -----------------------------------------------------------------------------
isoyearweek_to_year_c("2021-02")
isoyearweek_to_year_n("2021-02")
isoyearweek_to_week_c("2021-02")
isoyearweek_to_week_n("2021-02")

## -----------------------------------------------------------------------------
yrwk_19_20 <- fhidata::world_dates_isoyearweek[year %in% c(2019, 2020)]
head(yrwk_19_20)

