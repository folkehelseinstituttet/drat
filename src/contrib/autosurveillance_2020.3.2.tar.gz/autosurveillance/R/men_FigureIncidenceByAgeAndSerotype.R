men_DataCleaner_FigureIncidenceByAgeAndSerotype <- function(data, argset) {
  d <- men_DataCleaner_TableIncidenceByAgeAndSerotype(data, argset)
  d <- d[year != 9999]

  return(d)
}

men_ResultProducer_FigureIncidenceByAgeAndSerotype <- function(data, argset) {
  # data <- p$get_data()
  # argset <- p$get_argset("FigureIncidenceByAgeAndSerotype_16-19_ALL_WITH_TITLES_NB_2017_FALSE")

  title <- list(
    "NB"="Insidens fordelt etter serogrupper - alle aldersgrupper",
    "EN"="Incidence by serogroup - all age groups")[[argset$language]]

  title_y <- list("NB"="Antall meningokokk tilfeller per 100.000",
                  "EN"="Number of meningococcal cases per 100,000")[[argset$language]]

  if(argset$superfolder == "ALL_WITHOUT_TITLES"){
    title_y <- title
    title <- NULL
  }

  d <- men_DataCleaner_FigureIncidenceByAgeAndSerotype(data = data, argset = argset)

  if(argset$age=="16-19"){
    d <- d[age=="16-19"]
  } else {
    d <- d[age!="16-19"]
  }

  seros <- unique(d$serogroup)
  seros <- seros[!seros %in% c("Nm ina", "Total", "Totalt")]
  seros <- c(seros, "Nm ina", "Total", "Totalt")
  d[, serogroup := factor(serogroup, levels = seros)]

  if (argset$onlyShowTotal) {
    q <- ggplot(d[serogroup %in% c("Total", "Totalt")], aes(x = year, y = N / pop * 100000))
  } else {
    q <- ggplot(d, aes(x = year, y = N / pop * 100000, colour = serogroup, group = serogroup))
  }
  q <- q + geom_line(lwd = 2)
  q <- q + scale_colour_brewer(list(
    "NB" = "Serogrupper",
    "EN" = "Serogroups"
  )[[argset$language]], palette = "Set2")
  q <- q + scale_x_continuous(
    list(
      "NB" = "\u00C5r",
      "EN" = "Year"
    )[[argset$language]],
    breaks = seq(1996, argset$yearOfInterest, 1), minor_breaks = NULL
  )
  q <- q + scale_y_continuous(title_y)
  q <- q + expand_limits(y = 0)
  q <- q + labs(title = title)
  q <- q + labs(caption = DATA_CAPTION[[argset$language]])
  q <- q + theme_gray(base_size = THEME_BASE_SIZE)
  # q <- q + theme(legend.key.size = unit(10, "lines"))
  q <- q + theme(axis.text.x = element_text(angle = 90, hjust = 0.5, vjust = 0.5))
  saveA4(q,
    filename = argset$filename
  )
}
