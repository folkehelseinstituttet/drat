#' ipd_get_plan
#' @export
ipd_get_plan <- function() {
  set_config_ipd()

  org::set_results(c(
    "G:/Helseregistre/MSIS/MSIS_UtenPersonid/autosurveillance/results/ipd/",
    "/results/ipd/"
  ))

  p <- plnr::Plan$new()
  p$add_data(
    name = "master_data",
    fn = ipd_get_data
  )

  p$add_data(
    name = "master_pop",
    fn = ipd_get_pop
  )

  analyses <- expand.grid(
    superfolder = c("ALL_WITHOUT_TITLES", "ALL_WITH_TITLES", "SHAREPOINT"),
    language = c("NB", "EN"),
    stringsAsFactors = FALSE
  )
  setDT(analyses)
  analyses[, use_title := FALSE]
  analyses[superfolder %in% c("ALL_WITHOUT_TITLES"), use_title := TRUE]

  plan <- list()
  for (i in 1:nrow(analyses)) {
    a <- analyses[i, ]
    vaxDef <- config$ipd$vax_def_master
    vaxDefIncidenceAge <- config$ipd$vax_def_incidence_age_master
    if (a$language == "NB") {
      names(vaxDef)[names(vaxDef) == "NVT"] <- "Ikke-vaksine serotyper"
      vaxDefIncidenceAge[vaxDefIncidenceAge == "NVT"] <- "Ikke-vaksine serotyper"
    }

    seasonList <- unique(fhi::season(config$ipd$max_date - seq(1, 3650, 26)))

    for (seasonOfInterest in seasonList[1:3]) {
      ipd_create_folders(
        language = a$language,
        superfolder = a$superfolder,
        seasonOfInterest = seasonOfInterest
      )

      folder <- path(
        type = "season",
        language = a$language,
        superfolder = a$superfolder,
        time = seasonOfInterest
      )

      ## funnel plot for serotypes
      if (a$superfolder != "SHAREPOINT") {
        for (age in config$ipd$age_list_funnel[[a$language]]) {
          for (comparison in c("singleYearLast", "4yearbaseline")) {
            p$add_analysis(
              name = glue::glue("fig_funnel_season_{a$language}_{a$superfolder}_{seasonOfInterest}_{age}_{comparison}"),
              fn_name = "Figure_Funnel_Season",
              language = a$language,
              superfolder = a$superfolder,
              seasonOfInterest = seasonOfInterest,
              age = age,
              comparison = comparison,
              seasonList = seasonList,
              USE_TITLE = a$use_title,
              type = "season",
              time = seasonOfInterest,
              folder = folder
            )
            # Figure_Funnel_Season(
            #   rawSpecificNumbers,
            #   ageListFunnel,
            #   LANGUAGE=a$language,
            #   folder = folder,
            #   seasonOfInterest,
            #   seasonList,
            #   USE_TITLE=a$use_title
            # )
          }
        }
      }

      ## Figures_cumulative
      p$add_analysis(
        fn_name = "Figure_Cumulative",
        language = a$language,
        superfolder = a$superfolder,
        type = "season",
        time = seasonOfInterest,
        seasonOfInterest = seasonOfInterest,
        seasonList = seasonList,
        USE_TITLE = a$use_title,
        folder = folder
      )
      # Figure_Cumulative(
      #   rawGroupNumbers,
      #   ageListCumulative,
      #   seasonOfInterest,
      #   seasonList,
      #   LANGUAGE = a$language,
      #   folder = folder,
      #   USE_TITLE=a$use_title
      # )
    }

    ## TRUNCATING YEARS AS APPROPRIATE
    for (yearOfInterest in c(lubridate::year(config$ipd$max_date):(lubridate::year(config$ipd$max_date) - 2))) {
      ipd_create_folders(
        language = a$language,
        superfolder = a$superfolder,
        yearOfInterest = yearOfInterest
      )

      base_folder <- path(
        type = "year",
        language = a$language,
        superfolder = a$superfolder,
        time = yearOfInterest
      )

      ## Serotype specific table
      p$add_analysis(
        fn_name = "Table_Serotype",
        language = a$language,
        superfolder = a$superfolder,
        type = "season",
        time = seasonOfInterest,
        yearOfInterest = yearOfInterest,
        base_folder = base_folder
      )
      # Table_Serotype(
      #   rawSpecificNumbers,
      #   ageDef,
      #   yearOfInterest,
      #   base_folder = base_folder,
      #   LANGUAGE = a$language
      # )

      ## funnel plot for serotypes
      if (a$superfolder != "SHAREPOINT") {
        p$add_analysis(
          fn_name = "Figure_Funnel_Year",
          language = a$language,
          superfolder = a$superfolder,
          type = "season",
          time = seasonOfInterest,
          yearOfInterest = yearOfInterest,
          base_folder = base_folder,
          USE_TITLE = a$use_title
        )
        # Figure_Funnel_Year(
        #   rawSpecificNumbers,
        #   ageListFunnel,
        #   LANGUAGE = a$language,
        #   base_folder = base_folder,
        #   yearOfInterest,
        #   USE_TITLE = a$use_title
        # )

        # simpsons index
        p$add_analysis(
          fn_name = "Figure_Simpsons",
          language = a$language,
          superfolder = a$superfolder,
          type = "season",
          time = seasonOfInterest,
          yearOfInterest = yearOfInterest,
          base_folder = base_folder,
          USE_TITLE = a$use_title
        )
        # Figure_Simpsons(
        #   rawSpecificNumbers,
        #   ageListRestrictedAll,
        #   ageListSimpsons,
        #   DATA_CAPTION,
        #   yearOfInterest,
        #   base_folder = base_folder,
        #   LANGUAGE = a$language,
        #   USE_TITLE = a$use_title
        # )
      }

      ## Grouped table
      p$add_analysis(
        fn_name = "Table_Number_Incidence",
        language = a$language,
        superfolder = a$superfolder,
        type = "season",
        time = seasonOfInterest,
        yearOfInterest = yearOfInterest,
        base_folder = base_folder
      )
      # Table_Number_Incidence(
      #   correctedGroupNumbers,
      #   ageDef,
      #   yearOfInterest,
      #   LANGUAGE = a$language,
      #   base_folder = base_folder
      # )

      ## Figures_incidence_vax
      # correctedGroupNumbers[,age:=factor(age,levels=names(ageDef[[a$language]]))]

      p$add_analysis(
        fn_name = "Figure_Incidence_Vax",
        language = a$language,
        superfolder = a$superfolder,
        type = "season",
        time = seasonOfInterest,
        yearOfInterest = yearOfInterest,
        base_folder = base_folder,
        USE_TITLE = a$use_title
      )
      # Figure_Incidence_Vax(
      #   correctedGroupNumbers,
      #   ageListRestricted,
      #   yearOfInterest,
      #   LANGUAGE = a$language,
      #   base_folder = base_folder,
      #   USE_TITLE=a$use_title
      # )

      ## Figure_incidence_age
      p$add_analysis(
        fn_name = "Figure_Incidence_Age",
        language = a$language,
        superfolder = a$superfolder,
        type = "season",
        time = seasonOfInterest,
        yearOfInterest = yearOfInterest,
        base_folder = base_folder,
        vaxDefIncidenceAge = config$ipdvaxDefIncidenceAge,
        USE_TITLE = a$use_title
      )
      # Figure_Incidence_Age(
      #   correctedGroupNumbers,
      #   yearOfInterest,
      #   LANGUAGE = a$language,
      #   base_folder = base_folder,
      #   vaxDefIncidenceAge=vaxDefIncidenceAge,
      #   USE_TITLE=a$use_title
      # )
    }
  }

  return(p)
}
