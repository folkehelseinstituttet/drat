ipd_get_pop <- function() {
  retval <- fhidata::norway_population_b2020[location_code == "norge", c("year", "pop", "age")]
  setnames(retval, "age", "xage")

  return(retval)
}

ipd_get_data <- function() {
  if (org::project$computer_id == 1) {
    channel <- RODBC::odbcDriverConnect(connection = "Driver={SQL Server};SERVER=dm-prod;DATABASE=MsisAnalyse;")
    masterData <- RODBC::sqlQuery(channel, "SELECT Serotype, Alder\u00C5r, AlderM\u00E5neder, Pr\u00F8vedato\u00C5r, Pr\u00F8vedatoM\u00E5ned, Pr\u00F8vedato FROM ViewNominativ WHERE Diagnose='Syst. pneumokokksykdom';")
    RODBC::odbcClose(channel)

    saveRDS(masterData, file = sprintf("%s/ipd.RDS", org::project$data))

    # Serotype -> Pneusero
    # Alder\u00C5r -> Alaar
    # AlderM\u00E5neder -> Alm
    # Pr\u00F8vedato\u00C5r -> Paar
    # Pr\u00F8vedatoM\u00E5ned -> Pmnd
    # Pr\u00F8vedato -> Pdato

    masterData <- data.table(masterData)
    setnames(masterData, c("Pneusero", "Alaar", "Alm", "Paar", "Pmnd", "Pdato"))
  } else {
    masterData <- data.table(readRDS(file.path(
      org::project$data,
      "ipd.RDS"
    )))

    setnames(masterData, c("Pneusero", "Alaar", "Alm", "Paar", "Pmnd", "Pdato"))
    masterData[, Pdato := as.character(Pdato)]

    if (fhi::isoyear_n() > max(masterData$Paar)) {
      missingYears <- fhi::isoyear_n():(max(masterData$Paar) + 1)
      retval <- list()
      retval[[1]] <- masterData
      for (i in missingYears) {
        retval[[i]] <- masterData[Paar == max(masterData$Paar)]
        retval[[i]][, Paar := i]
        retval[[i]][, Pdato := stringr::str_replace(Pdato, sprintf("^%s", max(masterData$Paar)), as.character(i))]
      }
      masterData <- rbindlist(retval)
    }
  }

  return(masterData)
}
