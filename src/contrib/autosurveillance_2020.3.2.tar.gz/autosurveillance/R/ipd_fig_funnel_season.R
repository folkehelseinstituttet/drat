ipd_fig_funnel_season <- function(
                                  rawSpecificNumbers,
                                  ageListFunnel,
                                  LANGUAGE,
                                  folder,
                                  seasonOfInterest,
                                  seasonList,
                                  USE_TITLE = TRUE) {
  # data <- p$get_data()
  # argset <- p$get_argset("fig_funnel_season_NB_ALL_WITH_TITLES_2017/2018_65+ år_singleYearLast")
  # argset <- p$get_argset("fig_funnel_season_NB_ALL_WITH_TITLES_2017/2018_65+ år_4yearbaseline")

  pop <- ipd_clean_pop(data$master_pop, config$ipd$age[[argset$language]])
  rawGroupNumbers <- ipd_clean_raw_numbers(
    data$master_data,
    config$ipd$age[[argset$language]],
    config$ipd$vax_def_master
  )
  rawGroupNumbers <- merge(
    rawGroupNumbers,
    pop,
    by = c("age", "year")
  )

  rawSpecificNumbers <- ipd_clean_raw_numbers(
    data$master_data,
    ageDef = config$ipd$age[[argset$language]],
    config$ipd$vax_def_specific
  )
  rawSpecificNumbers <- merge(
    rawSpecificNumbers,
    pop,
    by = c("age", "year")
  )

  correctedGroupNumbers <- ipd_correct_group_numbers(
    rawGroupNumbers,
    config$ipd$vax_def_master
  )

  # a <- argset$age

  seasonOfInterestIndex <- which(argset$seasonOfInterest == argset$seasonList)
  if (argset$comparison == "singleYearLast") {
    baseline <- argset$seasonList[seasonOfInterestIndex + 1]
  } else if (argset$comparison == "4yearbaseline") {
    baseline <- argset$seasonList[(seasonOfInterestIndex + 1):(seasonOfInterestIndex + 4)]
  }

  baselineOldest <- baseline[length(baseline)]
  baselineSoonest <- baseline[1]

  if (argset$comparison == "singleYearLast" & argset$language == "NB") {
    title <- glue::glue(
      "{argset$age}, sammenlikning av serotyper",
      "{ifelse(argset$USE_TITLE,' ','\n')}i {argset$seasonOfInterest} med {baselineSoonest}"
    )
    xTitle <- sprintf("Antall tilfeller i %s", baselineSoonest)
    yTitle <- sprintf("Forhold av (antall tilfeller i %s/antall tilfeller i %s)", argset$seasonOfInterest, baselineOldest)
  } else if (argset$comparison == "singleYearLast" & argset$language == "EN") {
    title <- glue::glue(
      "{argset$age}, comparison of serotypes",
      "{ifelse(argset$USE_TITLE,' ','\n')}in {argset$seasonOfInterest} with {baselineSoonest}"
    )
    xTitle <- sprintf("Number of cases in %s", baselineSoonest)
    yTitle <- sprintf("Ratio of (number of cases in %s/number of cases in %s)", argset$seasonOfInterest, baselineOldest)
  } else if (argset$comparison == "4yearbaseline" & argset$language == "NB") {
    title <- glue::glue(
      "{argset$age}, sammenlikning av serotyper i {argset$seasonOfInterest}\n",
      "med gjennomsnittet fra {baselineOldest}-{baselineSoonest}"
    )
    xTitle <- sprintf("Gjennomsnittlig antall tilfeller i %s-%s", baselineOldest, baselineSoonest)
    yTitle <- sprintf("Forhold av (antall tilfeller i %s/gjennomsnittet i %s-%s)", ShortenSeason(argset$seasonOfInterest), ShortenSeason(baselineOldest), ShortenSeason(baselineSoonest))
  } else if (argset$comparison == "4yearbaseline" & argset$language == "EN") {
    title <- glue::glue(
      "{argset$age}, comparison of serotypes in {argset$seasonOfInterest}\n",
      "with average from {baselineOldest}-{baselineSoonest}"
    )
    xTitle <- sprintf("Average number of cases in %s-%s", baselineOldest, baselineSoonest)
    yTitle <- sprintf("Ratio of (number of cases in %s/average in %s-%s)", ShortenSeason(argset$seasonOfInterest), ShortenSeason(baselineOldest), ShortenSeason(baselineSoonest))
  }

  if (argset$seasonOfInterest == fhi::season(config$ipd$max_date) & argset$language == "NB") {
    title <- glue::glue("{title}", "\n(kun data f\u00F8r uke {fhi::isoweek_n()})")
  } else if (argset$seasonOfInterest == fhi::season(config$ipd$max_date) & argset$language == "EN") {
    title <- glue::glue("{title}", "\n(only data before week {fhi::isoweek_n()})")
  }

  plotData <- rawSpecificNumbers[
    time == "week" &
      age == argset$age &
      season %in% c(argset$seasonOfInterest, baseline) &
      !vaccine %in% c("missing", "All IPD")
  ]

  if (argset$seasonOfInterest == fhi::season(config$ipd$max_date)) {
    plotData <- plotData[s_week < fhi::x(fhi::isoweek_n())]
  }

  if (argset$comparison == "4yearbaseline") {
    plotData[season != argset$seasonOfInterest, season := baselineSoonest]
    plotData <- plotData[, .(num = mean(num)), by = .(vaccine, season, week)]
  }
  plotData <- plotData[, .(num = round(sum(num))), by = .(vaccine, season)]

  setorder(plotData, vaccine, season)
  plotData[, num_previous := shift(num), by = .(vaccine)]
  plotData <- plotData[season == argset$seasonOfInterest]

  plotData[num_previous == 0, num_previous := 1]
  plotData[num == 0, num := 1]
  plotData[, percentageChange := num / num_previous]

  upper <- stats::qpois(0.975, 1:max(plotData$num_previous))
  lower <- stats::qpois(0.025, 1:max(plotData$num_previous))
  confidenceIntervals <- data.table(num_previous = 1:max(plotData$num_previous), upper, lower)
  confidenceIntervals[, upperScaled := upper / num_previous]
  confidenceIntervals[, lowerScaled := lower / num_previous]

  plotData <- merge(plotData, confidenceIntervals, by = "num_previous")
  changeLevels <- list(
    "NB" = c("Signifikant \u00F8kning", "Ingen endring", "Signifikant reduksjon"),
    "EN" = c("Significant increase", "No change", "Significant decrease")
  )[[argset$language]]
  plotData[, change := changeLevels[2]]
  plotData[num > upper, change := changeLevels[1]]
  plotData[num < lower, change := changeLevels[3]]
  plotData[, change := factor(change, levels = changeLevels)]

  q <- ggplot(plotData, aes(x = num_previous))
  q <- q + geom_ribbon(data = confidenceIntervals, mapping = aes(ymax = log2(upperScaled), ymin = log2(lowerScaled)), alpha = 0.5)
  q <- q + geom_hline(yintercept = 0, lty = 2, colour = "red")
  q <- q + geom_label(aes(y = log2(percentageChange), label = vaccine, fill = change), hjust = 0.5, vjust = 0.5)
  if (nrow(plotData[change != changeLevels[2]]) > 0) q <- q + geom_label(data = plotData[change != changeLevels[2]], mapping = aes(y = log2(percentageChange), label = vaccine, fill = change))
  q <- q + scale_x_continuous(xTitle)
  q <- q + scale_fill_brewer("", palette = "RdBu", drop = FALSE)
  if (argset$USE_TITLE) {
    q <- q + labs(title = title)
    q <- q + scale_y_continuous(
      yTitle,
      breaks = c(-10:10), labels = 2^(-10:10)
    )
  } else {
    q <- q + scale_y_continuous(
      title,
      breaks = c(-10:10), labels = 2^(-10:10)
    )
  }
  q <- q + labs(caption = DATA_CAPTION[[argset$language]])
  q <- q + theme_gray(base_size = THEME_BASE_SIZE)
  if (argset$comparison == "singleYearLast") {
    fhiplot::save_a4(q,
      filename = file.path(argset$folder, "Figures_serotype_funnel_singleyearlast", sprintf("%s_Serotype_%s.png", argset$language, argset$age))
    )
  } else if (argset$comparison == "4yearbaseline") {
    fhiplot::save_a4(q,
      filename = file.path(argset$folder, "Figures_serotype_funnel_4yearbaseline", sprintf("%s_Serotype_%s.png", argset$language, argset$age))
    )
  }
}
