#' men_get_plan
#' @export
men_get_plan <- function() {
  set_config_men()

  org::set_results(c(
    "G:/Helseregistre/MSIS/MSIS_UtenPersonid/autosurveillance/results/meningococcal/",
    "/results/meningococcal/"
  ))

  p <- plnr::Plan$new()
  p$add_data(
    name = "master_data",
    fn = men_get_data
  )

  p$add_data(
    name = "master_pop",
    fn = men_get_pop
  )

  analyses <- expand.grid(
    superfolder = c("ALL_WITHOUT_TITLES", "ALL_WITH_TITLES", "SHAREPOINT"),
    language = c("NB", "EN"),
    yearOfInterest = c(2015:lubridate::year(lubridate::today())),
    fn_name = c(
      "TableIncidenceByAgeAndSerotype",
      "FigureIncidenceByAgeAndSerotype_allages",
      "FigureIncidenceByAgeAndSerotype_16-19",
      "FigureSerotypeByYear_allages",
      "FigureSerotypeByYear_16-19",
      "men_TableIncidenceByAge",
      #"TableIncidenceByMonth",
      #"FigureIncidenceByMonth1Year",
      #"FigureIncidenceByMonth1YearVs3",
      "men_fig_total_incidence_by_age_young",
      "men_fig_total_incidence_by_age_broad",
      "men_tab_total_incidence_by_age_young",
      "men_tab_total_incidence_by_age_broad"
    ),
    onlyShowTotal = as.logical(NA),
    stringsAsFactors = FALSE
  )
  setDT(analyses)

  # duplicating the analyses for onlyShowTotal=TRUE/FALSE
  temp1 <- analyses[fn_name %in% c(
    "FigureIncidenceByAgeAndSerotype_allages",
    "FigureIncidenceByAgeAndSerotype_16-19"
  )]
  temp2 <- copy(temp1)
  temp1[, onlyShowTotal := TRUE]
  temp2[, onlyShowTotal := FALSE]

  analyses <- analyses[!fn_name %in% c(
    "FigureIncidenceByAgeAndSerotype_allages",
    "FigureIncidenceByAgeAndSerotype_16-19"
  )]
  analyses <- rbind(
    analyses,
    temp1,
    temp2
  )

  # fixing age definitions
  analyses[, age_def := dplyr::case_when(
    fn_name == "FigureSerotypeByYear_allages" ~ "age_fig_serotype_by_year1",
    fn_name == "FigureSerotypeByYear_16-19" ~ "age_fig_serotype_by_year2",
    fn_name == "men_fig_total_incidence_by_age_young" ~ "age_young",
    fn_name == "men_fig_total_incidence_by_age_broad" ~ "age_broad",
    fn_name == "men_tab_total_incidence_by_age_young" ~ "age_young",
    fn_name == "men_tab_total_incidence_by_age_broad" ~ "age_broad"
  )]

  # fixing age filters
  analyses[, age := dplyr::case_when(
    fn_name == "FigureIncidenceByAgeAndSerotype_allages" ~ "allages",
    fn_name == "FigureIncidenceByAgeAndSerotype_16-19" ~ "16-19",
    fn_name == "FigureSerotypeByYear_allages" ~ "allages",
    fn_name == "FigureSerotypeByYear_16-19" ~ "16-19"
  )]

  analyses[, use_title := TRUE]
  analyses[superfolder %in% c("ALL_WITHOUT_TITLES"), use_title := FALSE]
  analyses[, name := glue::glue(
    "{fn_name}_{superfolder}_{language}_{yearOfInterest}_{onlyShowTotal}",
    fn_name = fn_name,
    superfolder = superfolder,
    language = language,
    yearOfInterest = yearOfInterest,
    onlyShowTotal = onlyShowTotal
  )]

  # create filename
  analyses[, filename :=
    dplyr::case_when(
      fn_name == "TableIncidenceByAgeAndSerotype" ~
      file.path(
        org::project$results_today,
        language,
        superfolder,
        yearOfInterest,
        "Tables",
        "incidence_by_age_and_serotype.csv"
      ),

      fn_name == "FigureIncidenceByAgeAndSerotype_allages" & onlyShowTotal == FALSE ~
      file.path(
        org::project$results_today,
        language,
        superfolder,
        yearOfInterest,
        "Figures",
        paste0(language, "_incidence_by_age_serotype_all_ages.png")
      ),
      fn_name == "FigureIncidenceByAgeAndSerotype_16-19" & onlyShowTotal == FALSE ~
      file.path(
        org::project$results_today,
        language,
        superfolder,
        yearOfInterest,
        "Figures",
        paste0(language, "_incidence_by_age_serotype_16-19.png")
      ),
      fn_name == "FigureIncidenceByAgeAndSerotype_allages" & onlyShowTotal == TRUE ~
      file.path(
        org::project$results_today,
        language,
        superfolder,
        yearOfInterest,
        "Figures",
        paste0(language, "_incidence_by_age_all_ages.png")
      ),
      fn_name == "FigureIncidenceByAgeAndSerotype_16-19" & onlyShowTotal == TRUE ~
      file.path(
        org::project$results_today,
        language,
        superfolder,
        yearOfInterest,
        "Figures",
        paste0(language, "_incidence_by_age_16-19.png")
      ),

      fn_name == "FigureSerotypeByYear_allages" ~
      file.path(
        org::project$results_today,
        language,
        superfolder,
        yearOfInterest,
        "Figures",
        paste0(language, "_serotype_by_year_all_ages.png")
      ),
      fn_name == "FigureSerotypeByYear_16-19" ~
      file.path(
        org::project$results_today,
        language,
        superfolder,
        yearOfInterest,
        "Figures",
        paste0(language, "_serotype_by_year_16-19.png")
      ),

      fn_name == "men_TableIncidenceByAge" ~
        file.path(
          org::project$results_today,
          language,
          superfolder,
          yearOfInterest,
          "Tables",
          "incidence_by_age.csv"
        ),

      fn_name == "men_fig_total_incidence_by_age_young" ~
        file.path(
          org::project$results_today,
          language,
          superfolder,
          yearOfInterest,
          "Figures",
          "fig_total_incidence_by_age_young.png"
        ),
      fn_name == "men_fig_total_incidence_by_age_broad" ~
        file.path(
          org::project$results_today,
          language,
          superfolder,
          yearOfInterest,
          "Figures",
          "fig_total_incidence_by_age_broad.png"
        ),

      fn_name == "men_tab_total_incidence_by_age_young" ~
        file.path(
          org::project$results_today,
          language,
          superfolder,
          yearOfInterest,
          "Tables",
          "tab_total_incidence_by_age_young.png"
        ),
      fn_name == "men_tab_total_incidence_by_age_broad" ~
        file.path(
          org::project$results_today,
          language,
          superfolder,
          yearOfInterest,
          "Tables",
          "tab_total_incidence_by_age_broad.png"
        ),

      TRUE ~ "x"
    )]

  # fixing analysis names
  xtabs(~analyses$fn_name)
  analyses[, fn_name := dplyr::case_when(
    fn_name == "FigureIncidenceByAgeAndSerotype_16-19" ~ "men_ResultProducer_FigureIncidenceByAgeAndSerotype",
    fn_name == "FigureIncidenceByAgeAndSerotype_allages" ~ "men_ResultProducer_FigureIncidenceByAgeAndSerotype",
    fn_name == "FigureSerotypeByYear_16-19" ~ "men_FigureSerotypeByYear",
    fn_name == "FigureSerotypeByYear_allages" ~ "men_FigureSerotypeByYear",
    fn_name == "men_fig_total_incidence_by_age_young" ~ "men_fig_total_incidence_by_age",
    fn_name == "men_fig_total_incidence_by_age_broad" ~ "men_fig_total_incidence_by_age",
    fn_name == "men_tab_total_incidence_by_age_young" ~ "men_tab_total_incidence_by_age",
    fn_name == "men_tab_total_incidence_by_age_broad" ~ "men_tab_total_incidence_by_age",
    TRUE ~ fn_name
  )]
  print(xtabs(~analyses$fn_name))

  p$add_analysis_from_df(df = analyses)
  #names(p$analyses)[100:150]

  for (i in 1:nrow(analyses)) {
    men_create_folders(
      language = analyses$language[i],
      superfolder = analyses$superfolder[i],
      yearOfInterest = analyses$yearOfInterest[i]
    )
  }

  return(p)
}
