men_DataCleaner_Basic <- function(data, argset) {
  # data <- p$get_data()
  # argset <- p$get_argset("TableIncidenceByAgeAndSerotype_ALL_WITHOUT_TITLES_NB_2015")

  # Incidence by age
  temp <- list()
  for (var in names(config$men$age[[argset$language]])) {
    temp[[var]] <- data$master_data[Alaar %in% config$men$age[[argset$language]][[var]]]
    temp[[var]][, age := var]
  }
  retval <- rbindlist(temp)

  # Incidence by hospital
  temp <- list()
  for (var in names(config$men$serogroup[[argset$language]])) {
    temp[[var]] <- retval[Smstoff %in% config$men$serogroup[[argset$language]][[var]]]
    temp[[var]][, serogroup := var]
  }
  retval <- rbindlist(temp)

  setnames(retval, "Paar", "year")
  setnames(retval, "Pmnd", "month")

  return(retval)
}

men_DataCleaner_Basic_specify <- function(data, argset) {
  # data <- p$get_data()
  # argset <- p$get_argset("TableIncidenceByAgeAndSerotype_ALL_WITHOUT_TITLES_NB_2015")

  # Incidence by age
  temp <- list()
  for (var in names(config$men[[argset$age_def]][[argset$language]])) {
    temp[[var]] <- data$master_data[Alaar %in% config$men[[argset$age_def]][[argset$language]][[var]]]
    temp[[var]][, age := var]
  }
  retval <- rbindlist(temp)

  # Incidence by hospital
  temp <- list()
  for (var in names(config$men$serogroup[[argset$language]])) {
    temp[[var]] <- retval[Smstoff %in% config$men$serogroup[[argset$language]][[var]]]
    temp[[var]][, serogroup := var]
  }
  retval <- rbindlist(temp)

  setnames(retval, "Paar", "year")
  setnames(retval, "Pmnd", "month")

  return(retval)
}
