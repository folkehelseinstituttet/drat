men_data_total_incidence_by_age <- function(data, argset){
  # data <- p$get_data()
  # argset <- p$get_argset("men_fig_total_incidence_by_age_young_ALL_WITH_TITLES_EN_2015_NA")
  d <- men_DataCleaner_Basic_specify(data, argset)
  d[,age:=factor(age,levels=names(config$men[[argset$age_def]][[argset$language]]))]
  d <- d[serogroup %in% c("Total","Totalt"),.(
    .N
  ),keyby=.(year, age)][CJ(
    unique(d$year),
    unique(d$age)
  )]
  d[is.na(N),N:=0]

  d <- d[year<=argset$yearOfInterest]
  return(d)
}

men_tab_total_incidence_by_age <- function(data, argset){
  # data <- p$get_data()
  # argset <- p$get_argset("men_fig_total_incidence_by_age_young_ALL_WITH_TITLES_EN_2015_NA")
  d <- men_data_total_incidence_by_age(data, argset)

  d <- AddTitleToDF(d, title = "Raw number of cases", copyColumnNames = TRUE)

  write.table(d,
              file = argset$filename,
              row.names = F,
              col.names = F,
              sep = ";",
              dec = ",",
              qmethod = "double"
  )
}

men_fig_total_incidence_by_age <- function(data, argset){
  # data <- p$get_data()
  # argset <- p$get_argset("men_fig_total_incidence_by_age_young_ALL_WITH_TITLES_EN_2015_NA")

  title <- list(
    "NB"="Insidens fordelt etter aldersgrupper",
    "EN"="Incidence by age groups")[[argset$language]]

  title_y <- list("NB"="Antall meningokokk tilfeller",
                  "EN"="Number of meningococcal cases")[[argset$language]]

  if(argset$superfolder == "ALL_WITHOUT_TITLES"){
    title_y <- title
    title <- NULL
  }

  d <- men_data_total_incidence_by_age(data, argset)


  q <- ggplot(d, aes(x = year, y = N, colour = age, group = age))
  q <- q + geom_line(lwd = 2)
  q <- q + scale_colour_brewer(list(
    "NB" = "Aldersgrupper",
    "EN" = "Age groups"
  )[[argset$language]], palette = "Set2")
  q <- q + scale_x_continuous(
    list(
      "NB" = "\u00C5r",
      "EN" = "Year"
    )[[argset$language]],
    breaks = seq(1996, argset$yearOfInterest, 1), minor_breaks = NULL
  )
  q <- q + scale_y_continuous(title_y)
  q <- q + expand_limits(y = 0)
  q <- q + labs(title = title)
  q <- q + labs(caption = DATA_CAPTION[[argset$language]])
  q <- q + theme_gray(base_size = THEME_BASE_SIZE)
  # q <- q + theme(legend.key.size = unit(10, "lines"))
  q <- q + theme(axis.text.x = element_text(angle = 90, hjust = 0.5, vjust = 0.5))
  saveA4(q,
         filename = argset$filename
  )
}
