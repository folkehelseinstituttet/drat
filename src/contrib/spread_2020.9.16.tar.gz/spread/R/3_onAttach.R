.onAttach <- function(libname, pkgname) {
  packageStartupMessage("\nPACKAGE: spread")
  packageStartupMessage("Version: 2020.09.16 at 09:37")
  packageStartupMessage("\nCommuter model and C++ code developed by Solveig Engebretsen and Andreas Nyg\u00E5rd Osnes")
  packageStartupMessage("Asymmetric mobility model and C++ code developed by Solveig Engebretsen")
  packageStartupMessage("Commuter ported to RCPP by Richard White")
  packageStartupMessage("Branching process developed by Gunnar Ro")
}
